
INSERT INTO `erp_db`.`ext_credit`
SELECT c.name, i.grand_total
FROM `erp_db`.`tabCustomer` c
JOIN `erp_db`.`tabSales Invoice` i ON i.customer = c.name
