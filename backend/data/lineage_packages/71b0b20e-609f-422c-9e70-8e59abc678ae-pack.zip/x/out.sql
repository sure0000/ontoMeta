
INSERT INTO `erp_db`.`ext_credit`
SELECT t.id FROM `tmp_scratch`.`staging_rows` t
