
    INSERT INTO `erp_db`.`ext_credit`
    SELECT c.name FROM `erp_db`.`tabCustomer` c
    JOIN `erp_db`.`tabSales Invoice` i ON i.customer = c.name AND i.territory = c.territory
    