SELECT c.name FROM `_d71df877e93eac81`.`tabCustomer` c WHERE c.disabled = 0;
