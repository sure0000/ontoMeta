INSERT INTO `_d71df877e93eac81`.`ext_customer_credit_daily`
SELECT t.id FROM `tmp_scratch`.`staging_rows` t;
