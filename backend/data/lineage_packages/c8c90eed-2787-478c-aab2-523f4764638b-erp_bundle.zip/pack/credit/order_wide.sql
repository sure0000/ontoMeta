CREATE TABLE `_d71df877e93eac81`.`dw_sales_order_wide` AS
SELECT so.name AS so_no, soi.item_code, soi.qty, c.customer_name
FROM `_d71df877e93eac81`.`tabSales Order` so
JOIN `_d71df877e93eac81`.`tabSales Order Item` soi ON soi.parent = so.name
JOIN `_d71df877e93eac81`.`tabCustomer` c ON so.customer = c.name
JOIN `_d71df877e93eac81`.`tabItem` it ON soi.item_code = it.name;
