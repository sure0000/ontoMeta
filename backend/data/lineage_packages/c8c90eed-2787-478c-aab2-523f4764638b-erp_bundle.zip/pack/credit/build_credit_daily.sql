-- 客户信用日汇总
INSERT INTO `_d71df877e93eac81`.`ext_customer_credit_daily`
WITH pay AS (
  SELECT p.party AS customer, p.posting_date, SUM(p.paid_amount) AS paid_amt
  FROM `_d71df877e93eac81`.`tabPayment Entry` p
  WHERE p.docstatus = 1
  GROUP BY p.party, p.posting_date
)
SELECT c.name AS customer_id, c.customer_name, SUM(i.grand_total) AS invoiced_amt, SUM(pay.paid_amt)
FROM `_d71df877e93eac81`.`tabCustomer` c
JOIN `_d71df877e93eac81`.`tabSales Invoice` i ON i.customer = c.name
LEFT JOIN pay ON pay.customer = c.name
GROUP BY c.name, c.customer_name;
